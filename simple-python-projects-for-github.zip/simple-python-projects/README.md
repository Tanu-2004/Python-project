# Simple Python Projects

Three tiny CLI projects to start your GitHub portfolio.

## Projects
1. `calculator.py` – basic +, -, *, / calculator.
2. `library_system.py` – add/view/issue books (in-memory, no extra libraries).
3. `number_guess.py` – number guessing game (1–100).

## Run locally
```bash
# choose any one
python calculator.py
python library_system.py
python number_guess.py
```

## Suggested improvements
- Add README badges and screenshots of terminal output.
- Convert `library_system.py` to use JSON/Excel storage.
- Write tests and docstrings.
