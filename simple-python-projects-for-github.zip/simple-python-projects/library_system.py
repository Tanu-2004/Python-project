# Library Book Allocation System (Simple - In Memory)

def add_book(library, book_name):
    library.append(book_name)
    print(f"'{book_name}' added to the library.")

def view_books(library):
    if not library:
        print("No books available.")
    else:
        print("Books in library:")
        for idx, book in enumerate(library, 1):
            print(idx, book)

def issue_book(library, book_name):
    if book_name in library:
        library.remove(book_name)
        print(f"'{book_name}' issued.")
    else:
        print("Book not available.")

library = []

while True:
    print("\n--- Library Menu ---")
    print("1. Add Book")
    print("2. View Books")
    print("3. Issue Book")
    print("4. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        book = input("Enter book name: ")
        add_book(library, book)
    elif choice == "2":
        view_books(library)
    elif choice == "3":
        book = input("Enter book name: ")
        issue_book(library, book)
    elif choice == "4":
        print("Exiting system...")
        break
    else:
        print("Invalid choice!")
